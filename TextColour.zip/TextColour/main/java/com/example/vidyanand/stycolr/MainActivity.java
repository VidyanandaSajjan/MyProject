package com.example.vidyanand.stycolr;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity
{
TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7,tv8;

    EditText et1,et2,et3,et4;

    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1=(EditText)findViewById(R.id.editText);
        et2=(EditText)findViewById(R.id.editText2);
        et3=(EditText)findViewById(R.id.editText3);
        et4=(EditText)findViewById(R.id.editText4);

        tv1=(TextView)findViewById(R.id.textView);
        tv2=(TextView)findViewById(R.id.textView2);
        tv3=(TextView)findViewById(R.id.textView3);
        tv4=(TextView)findViewById(R.id.textView4);

        tv5=(TextView)findViewById(R.id.textView5);

        tv6=(TextView)findViewById(R.id.textView6);

        tv7=(TextView)findViewById(R.id.textView7);
        tv8=(TextView)findViewById(R.id.textView8);

        btn=(Button) findViewById(R.id.button);
    }

    public void click(View v)
    {
        String Name =et1.getText().toString();
        String Place =et2.getText().toString();
        String Email =et3.getText().toString();
        String Number =et4.getText().toString();

        ArrayList<String> a1=new ArrayList<>();
        a1.add(Name);
        a1.add(Place);
        a1.add(Email);
        a1.add(Number);

        Iterator<String> it=a1.iterator();

        String array[]=new String[a1.size()];
        int i=0;
        while (it.hasNext())
        {
            array[i]=it.next();
            i++;
        }

        tv5.setText(array[0]);
        tv6.setText(array[1]);
        tv7.setText(array[2]);
        tv8.setText(array[3]);

    }

}

