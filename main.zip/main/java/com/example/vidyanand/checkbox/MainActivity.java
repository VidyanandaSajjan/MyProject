package com.example.vidyanand.checkbox;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
     Button choice;
    CheckBox red,green,blue,whit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        choice=(Button)findViewById(R.id.button_submitt);
        red=(CheckBox)findViewById(R.id.checkBox_red);
        green=(CheckBox)findViewById(R.id.checkBox_green);
        blue=(CheckBox)findViewById(R.id.checkBox_blue);
        whit=(CheckBox)findViewById(R.id.checkBox_white);

        choice.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                StringBuffer stb=new StringBuffer();
            if (red.isChecked())
            {
                stb.append("red\n");
            }
                if (green.isChecked())
                {
                    stb.append("green\n");
                }
                if (blue.isChecked())
                {
                    stb.append("blue\n");

                }
                if (whit.isChecked())
                {
                    stb.append("whit\n");
                }

                Toast.makeText(MainActivity.this,"selected rose:\n"+stb,Toast.LENGTH_SHORT).show();
            }
        });

    }
}
