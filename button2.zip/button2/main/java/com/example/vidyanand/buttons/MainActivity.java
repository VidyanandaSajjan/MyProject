package com.example.vidyanand.buttons;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button bt1, bt2, bt3;
    TextView tv1, tv2, tv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = (Button) findViewById(R.id.button);
        tv1 = (TextView) findViewById(R.id.textView);

        bt2 = (Button) findViewById(R.id.button2);
        bt2.setOnClickListener(this);
        tv2 = (TextView) findViewById(R.id.textView2);

        bt3 = (Button) findViewById(R.id.button3);
        tv3 = (TextView) findViewById(R.id.textView3);

    }

    public void submit3(View v)
    {
        String data1 = "Add you details";
        tv3.setText(data1);
    }

    public void onClick(View v)
    {

        String data2 = "Hi Friends";
        tv2.setText(data2);

    }

    public void submit1(View v)
    {
        String data3="Bye";
        tv1.setText(data3);
    }


}
