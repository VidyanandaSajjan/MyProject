package com.example.vidyanand.toastview;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.AlteredCharSequence;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
RadioGroup rg;
    RadioButton bt,bt1,bt2,bt3;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt=(RadioButton)findViewById(R.id.Button_Choice);
        bt1=(RadioButton)findViewById(R.id.Button_Choice2);
        bt2=(RadioButton)findViewById(R.id.Button_Choice3);
        bt3=(RadioButton)findViewById(R.id.Button_Choice4);

        bt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
               Toast.makeText(getApplication(),"every dog has a day",Toast.LENGTH_LONG).show();
            }
        });

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
            Toast.makeText(getApplicationContext(),"Life is short",Toast.LENGTH_LONG).show();
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(),"check your life style",Toast.LENGTH_LONG).show();
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Toast.makeText(getApplicationContext(),"show me your lifestyle",Toast.LENGTH_LONG).show();
            }
        });

    }
}
