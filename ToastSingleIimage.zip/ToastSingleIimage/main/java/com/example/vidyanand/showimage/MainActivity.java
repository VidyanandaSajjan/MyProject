package com.example.vidyanand.showimage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
Button bt;
    LayoutInflater l=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bt=(Button)findViewById(R.id.button);

        bt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                l=getLayoutInflater();
                        View layout=l.inflate(R.layout.image,(ViewGroup)findViewById(R.id.imageView));
               Toast t= new Toast(getApplicationContext());
                t.setDuration(Toast.LENGTH_SHORT);
                t.setGravity(Gravity.CENTER,0,0);
                t.setView(layout);
                t.show();

            }
        });

    }
}
