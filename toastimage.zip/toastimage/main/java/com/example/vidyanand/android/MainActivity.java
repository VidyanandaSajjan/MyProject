package com.example.vidyanand.android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
RadioGroup gr;

    RadioButton rd,rd1,rd2;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gr=(RadioGroup)findViewById(R.id.radiogroup_v);

        rd=(RadioButton)findViewById(R.id.radioButton);

        rd1=(RadioButton)findViewById(R.id.radioButton2);

        rd2=(RadioButton)findViewById(R.id.radioButton3);

        rd.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

     LayoutInflater lf=getLayoutInflater();
                View vw=lf.inflate(R.layout.image,(ViewGroup)findViewById(R.id.first));
                Toast t=new Toast(getApplicationContext());
                t.setGravity(Gravity.CENTER,0,0);
                t.setView(vw);
                t.setDuration(Toast.LENGTH_SHORT);
                t.show();




            }
        });
        rd1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v1)
            {
           LayoutInflater lf1=getLayoutInflater();
                View vw1=lf1.inflate(R.layout.image1,(ViewGroup)findViewById(R.id.second));
                Toast t=new Toast(getApplicationContext());
                t.setDuration(Toast.LENGTH_SHORT);
                t.setView(vw1);
                t.setGravity(Gravity.CENTER,0,0);
                t.show();
            }
        });
        rd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {
         LayoutInflater lf2=getLayoutInflater();
                View vw2=lf2.inflate(R.layout.image3,(ViewGroup)findViewById(R.id.third));
                Toast t=new Toast(getApplicationContext());
                t.setGravity(Gravity.CENTER,0,0);
                t.setView(vw2);
                t.setDuration(Toast.LENGTH_SHORT);
                t.show();
            }
        });




    }

}
